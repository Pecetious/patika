# Node + Socket.IO + React Chat App (Backend)

### Kullanılan Teknolojiler

- Node.js
- Express.js
- Socket.io
- Redis
